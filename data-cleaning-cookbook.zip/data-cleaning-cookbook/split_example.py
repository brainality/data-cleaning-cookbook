from src.split_by_columns import split_dataset_by_columns

# Example: change the path and columns to your dataset
split_dataset_by_columns("data/sample/Northern_Ireland_Online_Crime.csv", ["sex", "age"])
